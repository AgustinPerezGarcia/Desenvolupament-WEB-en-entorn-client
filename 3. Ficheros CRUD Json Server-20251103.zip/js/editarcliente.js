/*EDITAR UN REGISTRO:
  Todo lo relacionado con las dos fases de la edición
*/